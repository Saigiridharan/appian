# Appian Expression Rule Standards

## Structure
- Keep expression rules small and reusable.
- Keep rule intent clear from the name and parameters.
- Prefer maintainability and readability over clever expressions.

## Inputs
- Use rule inputs clearly and defensively.
- Handle null and empty values explicitly.
- Validate assumptions about data shape before indexing fields.

## Logic
- Avoid unnecessary nested if logic when a clearer structure is possible.
- Avoid expensive repeated evaluations.
- Avoid large loops where possible.
- Prefer extracted helper rules when logic becomes difficult to read.

## Reuse
- Use constants for repeated literal values.
- Standardize repeated logic into reusable expression rules.
