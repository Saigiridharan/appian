# Appian SAIL Standards

## Layout and readability
- Use readable local variables with meaningful names.
- Prefer modular interfaces and reusable expression rules.
- Keep sections logically grouped.
- Keep component nesting manageable.
- Keep showWhen conditions readable.

## Data handling
- Use pagingInfo for grids, record lists, and query-driven displays.
- Avoid loading excessive data into interfaces.
- Avoid unbounded query patterns.
- Keep query logic maintainable.

## Validations
- Use validations close to input components.
- Use clear validation messages.
- Keep required and conditional validation logic understandable.

## Reuse
- Use constants or reusable rules instead of repeated literals.
- Reuse common Appian UI patterns where possible.

## Maintainability
- Keep saveInto logic understandable.
- Keep interfaces easy to review and update.
- Prefer clarity over overly compressed expressions.
