# Appian Form Patterns

## Create Form Pattern
Recommended structure:
- title or section header
- logical field grouping
- required validations
- primary action and cancel action
- clean saveInto usage

## Edit Form Pattern
Recommended structure:
- prepopulated values
- clear editable vs read-only fields
- consistent validations
- safe update behavior

## Review reminders
- Are required validations clear?
- Is the layout easy to scan?
- Is saveInto logic maintainable?
- Are defaults and assumptions explicit?
