# Appian Grid Patterns

## Record Grid Pattern
Use when displaying a list of records.

Recommended characteristics:
- pagingInfo is present
- clear column definitions
- optional search placeholder
- optional filters
- readable row actions
- maintainable display logic

## Summary Grid Pattern
Use when displaying key fields only.

Recommended characteristics:
- limited columns
- strong readability
- consistent status display
- no unnecessary visual noise

## Review reminders
- Is the grid query bounded?
- Are columns relevant?
- Is pagingInfo used correctly?
- Is the display logic easy to maintain?
