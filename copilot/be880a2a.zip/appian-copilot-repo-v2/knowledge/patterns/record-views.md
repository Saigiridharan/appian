# Appian Record View Patterns

## Summary View
Use for concise business context.

Recommended contents:
- key identifiers
- status
- important business fields
- minimal but useful actions

## Detailed View
Use when deeper review is needed.

Recommended contents:
- grouped sections
- business context blocks
- related information
- controlled amount of information per section

## Review reminders
- Is the record view overloaded?
- Are sections meaningful?
- Is the information hierarchy clear?
