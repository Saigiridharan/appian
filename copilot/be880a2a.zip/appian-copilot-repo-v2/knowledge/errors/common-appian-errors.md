# Common Appian Errors

## Expression evaluation error
Likely causes:
- invalid parameter type
- null handling issue
- incorrect function input
- unexpected data shape

Inspect:
- rule inputs
- function parameters
- expression editor test output
- interface local variables

Fix ideas:
- add null checks
- correct parameter types
- simplify nested logic for debugging
- validate intermediate values

## Cannot index property of null
Likely causes:
- indexing a field from a null dictionary
- missing CDT or record field
- null ri! or local! value

Inspect:
- source object before indexing
- ri! values
- local! values
- upstream query result

Fix ideas:
- add a!isNullOrEmpty checks
- provide defaults
- guard field access
- validate source data earlier

## Invalid index or field reference
Likely causes:
- wrong field name
- wrong dictionary structure
- mismatched source type

Inspect:
- field names
- source structure
- record type or CDT mapping

Fix ideas:
- use correct field references
- confirm data shape
- align rule input data with usage

## Interface component save error
Likely causes:
- invalid save target
- incompatible saveInto target
- invalid value type

Inspect:
- saveInto targets
- local variable types
- rule input writability

Fix ideas:
- align component value type with save target
- simplify saveInto
- validate write targets

## Query returned too much data or interface performance issue
Likely causes:
- missing pagingInfo
- unbounded query pattern
- too much data loaded into interface

Inspect:
- query paging configuration
- interface load behavior
- repeated refresh or expensive calculations

Fix ideas:
- add pagingInfo
- restrict returned fields and data volume
- move heavy logic into reusable rules
