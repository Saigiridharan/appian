# Example Prompt: Employee Form

Generate Appian SAIL code for an Employee create form with:
- employeeId
- firstName
- lastName
- email
- department
- joiningDate
- status

Use:
- required validations
- clean section layout
- readable saveInto logic
- Appian-only output
