# Appian Review Checklist

Use this checklist while reviewing Appian SAIL or expression rules.

## Readability
- Are names meaningful?
- Is the structure easy to follow?
- Is the code too deeply nested?

## Reuse
- Should repeated logic become an expression rule?
- Should repeated literals become constants?

## Data handling
- Is pagingInfo used where needed?
- Is the query bounded?
- Are nulls handled clearly?

## Maintainability
- Is the code easy to modify?
- Are validations understandable?
- Is saveInto logic easy to review?

## Output expectation
Return:
1. Findings
2. Appian reason
3. Corrected Appian code
4. Score out of 10
