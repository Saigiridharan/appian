# Example Prompt: Employee Grid

Generate Appian SAIL code for an Employee record list grid.

Use:
- pagingInfo
- employeeId
- firstName
- lastName
- department
- status

Add:
- search placeholder
- filter placeholder
- readable local variables
- Appian-only output
