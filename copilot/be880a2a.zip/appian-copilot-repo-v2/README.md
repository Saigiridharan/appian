# Appian Copilot Repo V2

This repository is designed to make GitHub Copilot in VS Code behave like an Appian-only development agent.

## Goal
Provide Appian-focused help for:
- SAIL code generation
- Appian error solutions
- Appian SAIL patterns
- Appian SAIL and expression rule code review
- Appian record and query guidance
- Appian standards-driven prompting

## How it works
- `.github/copilot-instructions.md` provides always-on repository instructions.
- `AGENTS.md` defines the Appian agent role and output style.
- `.github/instructions/*.instructions.md` adds path-specific behavior.
- `.github/prompts/*.prompt.md` provides reusable prompt templates for VS Code.
- `knowledge/` contains standards, patterns, naming guidance, and error help.
- `examples/` contains ready-to-use Appian prompt examples.

## Suggested VS Code usage
Open Copilot Chat in this repository and use:
- `/generate-employee-grid`
- `/create-employee-form`
- `/review-sail-code`
- `/review-expression-rule`
- `/solve-appian-error`
- `/suggest-sail-pattern`
- `/generate-record-summary-view`
- `/review-record-query`
- `/generate-interface-from-requirements`

## Expected behavior
All responses should stay Appian-only and follow the standards defined in this repository.
