---
applyTo: "**/*"
---

# Appian Expression Rule Instructions

When the request is about Appian expression rules:
- Prefer small and reusable rules.
- Handle null and empty values explicitly.
- Avoid overly nested if conditions where readability suffers.
- Avoid expensive repeated evaluations.
- Use constants instead of repeated literals.
- Return corrected Appian expression rule code where possible.
