---
applyTo: "**/*"
---

# Appian SAIL Instructions

When the request is about Appian SAIL:
- Prefer a!localVariables() when it improves readability.
- Keep layouts logically grouped.
- Use validations close to the relevant components.
- Use pagingInfo for grid and query-driven interfaces.
- Avoid overly dense interface structures.
- Keep saveInto logic understandable.
- Keep showWhen conditions readable.
- Return Appian SAIL only.
