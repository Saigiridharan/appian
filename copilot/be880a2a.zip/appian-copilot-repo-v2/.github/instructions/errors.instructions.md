---
applyTo: "**/*"
---

# Appian Error Instructions

When the request is about Appian errors:
- Explain the error in Appian context only.
- Identify likely Appian cause.
- Tell the user where to inspect in Appian.
- Provide exact Appian fix steps.
- Provide corrected Appian example if relevant.
