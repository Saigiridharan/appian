---
agent: "agent"
description: "Generate an Appian employee record grid"
---

Generate Appian SAIL code for an Employee record list grid.

Requirements:
- Use Appian best practices
- Use pagingInfo
- Include clear columns
- Include search and filter placeholders
- Keep local variables readable
- Return Appian-only output

Business context:
${input:businessContext:Optional Appian business context}

Fields to show:
${input:fields:employeeId, firstName, lastName, department, status}

Please return:
1. Assumptions
2. Appian SAIL code
3. Short Appian implementation notes
