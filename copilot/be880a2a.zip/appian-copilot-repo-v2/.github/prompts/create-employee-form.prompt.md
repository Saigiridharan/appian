---
agent: "agent"
description: "Create an Appian employee form"
---

Generate Appian SAIL code for an Employee create form.

Fields:
- employeeId
- firstName
- lastName
- email
- department
- joiningDate
- status

Requirements:
- Appian validations
- Clean section layout
- Readable saveInto usage
- Appian-only response

Business context:
${input:businessContext:Optional Appian business context}

Please return:
1. Assumptions
2. Appian SAIL code
3. Validation notes
