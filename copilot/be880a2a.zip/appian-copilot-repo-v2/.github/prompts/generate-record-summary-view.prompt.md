---
agent: "agent"
description: "Generate an Appian record summary view"
---

Generate an Appian SAIL record summary view.

Context:
${input:context:Describe the record and its business purpose}

Requirements:
- Show key business identifiers
- Show status clearly
- Group related information into sections
- Keep the layout readable and maintainable
- Return only Appian-focused output

Please return:
1. Assumptions
2. Appian SAIL code
3. Summary view notes
