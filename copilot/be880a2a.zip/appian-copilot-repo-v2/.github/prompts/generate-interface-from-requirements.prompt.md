---
agent: "agent"
description: "Generate an Appian interface from business requirements"
---

Generate Appian SAIL code from the following business requirements.

Requirements:
${input:requirements:Paste the Appian business requirements here}

Constraints:
- Use Appian-only design
- Prefer modular structure
- Include assumptions where details are missing
- Keep validations and layout readable

Please return:
1. Assumptions
2. Appian approach
3. Appian SAIL code
4. Notes
