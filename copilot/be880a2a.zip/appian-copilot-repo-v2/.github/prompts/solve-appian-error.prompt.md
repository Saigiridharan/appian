---
agent: "agent"
description: "Solve an Appian error"
---

Explain this Appian error in Appian context only.

Error:
${input:error:Paste Appian error message here}

Please return:
1. Error meaning
2. Likely Appian root cause
3. Where to inspect in Appian
4. Fix steps
5. Corrected Appian example
