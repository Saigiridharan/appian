---
agent: "agent"
description: "Review Appian SAIL code for standards"
---

Review the following Appian SAIL code against Appian standards.

Check for:
- readability
- reuse
- paging
- null handling
- performance
- maintainability
- validation quality

Code:
${input:code:Paste Appian SAIL code here}

Please return:
1. Findings
2. Why each issue matters in Appian
3. Corrected Appian code
4. Review score out of 10
