---
agent: "agent"
description: "Review an Appian record query or query rule"
---

Review the following Appian record query, queryEntity, or expression-based query logic.

Check for:
- pagingInfo usage
- bounded data retrieval
- readability
- null safety
- maintainability
- unnecessary repeated evaluations

Code:
${input:code:Paste Appian query logic here}

Please return:
1. Findings
2. Why each issue matters in Appian
3. Corrected Appian query logic
4. Review score out of 10
