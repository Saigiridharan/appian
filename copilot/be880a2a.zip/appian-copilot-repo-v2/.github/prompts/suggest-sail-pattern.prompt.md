---
agent: "agent"
description: "Suggest an Appian SAIL pattern"
---

Suggest the best Appian SAIL pattern for this use case.

Use case:
${input:useCase:Describe the Appian requirement}

Constraints:
${input:constraints:Optional Appian constraints}

Please return:
1. Recommended Appian pattern
2. Why it fits
3. Suggested Appian structure
4. Optional starter Appian SAIL snippet
