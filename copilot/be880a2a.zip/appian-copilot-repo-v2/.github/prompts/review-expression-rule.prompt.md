---
agent: "agent"
description: "Review Appian expression rule for standards"
---

Review the following Appian expression rule.

Check for:
- null handling
- readability
- reusability
- repeated literals
- expensive evaluations
- maintainability

Code:
${input:code:Paste Appian expression rule here}

Please return:
1. Findings
2. Why each issue matters in Appian
3. Corrected Appian expression rule
4. Review score out of 10
